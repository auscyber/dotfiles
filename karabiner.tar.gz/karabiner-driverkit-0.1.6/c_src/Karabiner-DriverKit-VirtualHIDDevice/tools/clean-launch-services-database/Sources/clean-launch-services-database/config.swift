let bundleIdentifiers = [
  "org.pqrs.HIDManagerTool",
  "org.pqrs.Karabiner-VirtualHIDDevice-Daemon",
  "org.pqrs.Karabiner-VirtualHIDDevice-Manager",
  "org.pqrs.Karabiner-VirtualHIDDevice-SMAppServiceExample",
  "org.pqrs.virtual-hid-device-service-client",
]
