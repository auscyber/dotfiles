# driverkit

driverkit is a minimal wrapper around [Karabiner-DriverKit-VirtualHIDDevice (dext)](https://github.com/pqrs-org/Karabiner-DriverKit-VirtualHIDDevice) and [Karabiner-VirtualHIDDevice (kext)](https://github.com/pqrs-org/Karabiner-VirtualHIDDevice) intended for kanata
macos support.

## Installation

Update the submodules first

    git submodule update --init --recursive

then

    cargo build
